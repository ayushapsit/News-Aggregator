from django.contrib import admin
from .models import Headline,EHeadline,SHeadline,PHeadline,LHeadline,ENHeadline, Bookmark

admin.site.register(Headline)
admin.site.register(EHeadline)
admin.site.register(SHeadline)
admin.site.register(PHeadline)
admin.site.register(LHeadline)
admin.site.register(ENHeadline)
admin.site.register(Bookmark)

